package com.example.psesecurity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
