package com.example.psegame

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
