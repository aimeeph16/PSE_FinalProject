package com.example.psesecuritycam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
