export type AmplifyDependentResourcesAttributes = {
    "auth": {
        "psesecuritycam81d680d7": {
            "IdentityPoolId": "string",
            "IdentityPoolName": "string",
            "UserPoolId": "string",
            "UserPoolArn": "string",
            "UserPoolName": "string",
            "AppClientIDWeb": "string",
            "AppClientID": "string"
        }
    },
    "analytics": {
        "psesecuritycam": {
            "Region": "string",
            "Id": "string",
            "appName": "string"
        }
    }
}